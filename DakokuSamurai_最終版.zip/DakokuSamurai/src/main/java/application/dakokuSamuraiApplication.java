package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class dakokuSamuraiApplication {
	//H2に接続準備
	final String JDBC_URL = "jdbc:h2:C:/dakokuSamuraiDB/dakokuSamuraiDB";
	final String DB_USER = "dakokuSamurai";
	final String DB_PASSWORD = "dakokusamurai";

	public static void main(String[] args) {
		execute();
	}

	public static void execute() {
		//insertMonthReq();
		//prepareDummyData();
	}

	//insertMonthReq(int att_status_id, String status, int created_users_id)
	public static void insertMonthReq() {
		// データベースに接続するConnectionオブジェクトを取得
		final String JDBC_URL = "jdbc:h2:C:/dakokuSamuraiDB/dakokuSamuraiDB";
		final String DB_USER = "dakokuSamurai";
		final String DB_PASSWORD = "dakokusamurai";
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
			System.out.println("H2データベースに接続しました。");

			//INSERT文の準備
			String insertSql = "INSERT INTO month_req (att_status_id, status, created_users_id, updated_users_id)\n"
					+ "VALUES (1, 1, 13, 13);";
			//インスタンス生成
			PreparedStatement pStmt = conn.prepareStatement(insertSql);

			//INSERTを実行
			pStmt.execute();

			//結果表示
			System.out.println("データを追加しました。");

		} catch (SQLException e) {
			System.out.println("H2データベースへの接続中にエラーが発生しました。");
			e.printStackTrace();
		}
	}

	
//	private static List<Request> prepareDummyData() {
		// 仮のダミーデータを生成する
		// 例えば、Request クラスを作成してそのリストを返す
		// List<Request> requests = someService.getAllRequests();
		// return requests;
		//return null; // 仮の実装のため、null を返す
//		List<Request> requestList = new ArrayList<>();
//		// ダミーデータを追加
//		for (int i = 0; i < 10; i++) {
//			requestList.add(new Request("" + i, 1, 0, "承認者"));
//			System.out.println(requestList);
//		}
//
//		return requestList;
//	}
}
