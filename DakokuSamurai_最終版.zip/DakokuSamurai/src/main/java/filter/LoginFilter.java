package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter("")
public class LoginFilter implements Filter {

	/**
	 * @see HttpFilter#HttpFilter()
	 */
	public LoginFilter() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		String s = httpRequest.getServletPath();
		
		  // JSP ページへの直接アクセスかどうかを判定する
        String requestURI = httpRequest.getRequestURI();
        
     // /WEB-INF/jsp/ で始まり、.jsp で終わるリクエストに対する処理
        if (requestURI.contains("/WEB-INF/jsp/") && requestURI.endsWith(".jsp")) {
            // セッションにユーザー情報がない場合、ログイン画面にリダイレクト
//            HttpSession session = httpRequest.getSession(false); // 既存のセッションを取得（なければ新規作成しない）
            
            if (httpRequest.getSession().getAttribute("sessionUsersBean") == null) {
            	System.out.println("セッション情報がないため、ログイン画面に戻ります");
                httpResponse.sendRedirect("/index.jsp");
                return;
            }
        }else { 
        	System.out.println("セッションに利用者情報を保存しました");
        	chain.doFilter(request, response);
        }
        
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
