

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.StampBean;
import beans.UsersBean;
import logic.AttStatusLogic;

/**
 * Servlet implementation class Sample
 */
@WebServlet("/Sample")
public class Sample extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sample() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UsersBean usersBean = new UsersBean();
		Date date = new Date();
		usersBean.setEmp_no("12345");
		usersBean.setEmp_name("田中　一郎");
		usersBean.setYear_and_month(date);
		request.setAttribute("usersBean", usersBean);
		
		
//		StampBean stampBean = new StampBean();
//		stampBean.setStamp_date(date);
//		stampBean.setWorkIn_raw(LocalTime.of(8, 55));
//		stampBean.setWorkOut_raw(LocalTime.of(18,05 ));
//		stampBean.setWorkIn_re(LocalTime.of(9, 00));
//		stampBean.setWorkOut_re(LocalTime.of(18,00 ));
//		stampBean.setWork_status(6);
//		stampBean.setWeek(date.getDay());
//		System.out.println(stampBean.getWeek());
//		stampBean.setRest_time(LocalTime.of(1,00 ));
//		stampBean.setReal_work_time(LocalTime.of(8,00 ));
//		
//		
//		List<StampBean> stampBeans = new ArrayList<>();
//		for (int i = 0 ; i < 10; i++) {
//			stampBeans.add(stampBean);
//		}
		
		// セッションから利用者IDを取得
		HttpSession session = request.getSession();
		UsersBean sessionUsersBean = (UsersBean) session.getAttribute("sessionUsersBean");
		int users_id = sessionUsersBean.getUsers_id();
		
		AttStatusLogic attStatusLogic = new AttStatusLogic();
//		UsersBean usersBean = attStatusLogic.findMyAttStatusUsers(users_id);
		//勤怠状況表の表示
		List<StampBean> stampBean = attStatusLogic.findMyAttStatusMonthStamp(users_id, date);
//		List<StampBean> stampBean = attStatusLogic.findMyAttStatusMonthStamp(users_id, date);
		
		request.setAttribute("stampBeans", stampBean);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("attendanceStatus.jsp");
		dispatcher.forward(request, response);
	}

}
