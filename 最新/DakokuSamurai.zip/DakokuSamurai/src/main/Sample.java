

import java.io.IOException;
import java.time.LocalTime;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.StampBean;
import beans.UsersBean;

/**
 * Servlet implementation class Sample
 */
@WebServlet("/Sample")
public class Sample extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Sample() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UsersBean usersBean = new UsersBean();
		Date date = new Date();
		usersBean.setEmp_no("12345");
		usersBean.setEmp_name("田中　一郎");
		usersBean.setYear_and_month(date);
		request.setAttribute("usersBean", usersBean);
		
		
		StampBean stampBean = new StampBean();
		stampBean.setStamp_date(date);
		stampBean.setWorkIn_raw(LocalTime.of(8, 55));
		stampBean.setWorkOut_raw(LocalTime.of(18,05 ));
		stampBean.setWorkIn_re(LocalTime.of(9, 00));
		stampBean.setWorkOut_re(LocalTime.of(18,00 ));
		stampBean.setWork_status(6);
		stampBean.setWeek(date.getDay());
		System.out.println(stampBean.getWeek());
		stampBean.setRest_time(LocalTime.of(1,00 ));
		stampBean.setReal_work_time(LocalTime.of(8,00 ));
		
		
		request.setAttribute("stampBean", stampBean);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("attendanceStatusDetail.jsp");
		dispatcher.forward(request, response);
	}

}
